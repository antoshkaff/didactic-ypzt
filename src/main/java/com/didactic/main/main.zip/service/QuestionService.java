package com.devrezaur.main.service;

import com.devrezaur.main.model.Question;
import com.devrezaur.main.model.Topic;
import com.devrezaur.main.repository.QuestionRepo;
import com.devrezaur.main.repository.TopicRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class QuestionService {

    @Autowired
    private QuestionRepo questionRepository;

    @Autowired
    private TopicRepo topicRepository;

    public List<Question> getAllQuestions() {
        return questionRepository.findAll();
    }

    public List<Question> getQuestionsByTopic(String topicName) {
        Optional<Topic> topicOpt = topicRepository.findByTopicName(topicName);
        if (topicOpt.isPresent()) {
            return questionRepository.findByTopic(topicOpt.get());
        } else {
            return Collections.emptyList();
        }
    }

    public void saveQuestion(Question question) {
        questionRepository.save(question);
    }

    public void saveAllQuestions(List<Question> questions) {
        questionRepository.saveAll(questions);
    }
}